const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

const userSchema = new mongoose.Schema({
  username: String,
  password: String,
  score: Number,
  wallet: String
});
const User = mongoose.model('User', userSchema);

app.post('/api/signup', async (req, res) => {
  const { username, password, wallet } = req.body;
  const existing = await User.findOne({ username });
  if (existing) return res.json({ error: 'Username taken' });
  const user = await User.create({ username, password, wallet, score: 0 });
  res.json({ message: 'Signup successful' });
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username, password });
  if (!user) return res.json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
  res.json({ token });
});

app.post('/api/score', async (req, res) => {
  const token = req.headers.authorization;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (parseFloat(req.body.score) > user.score) {
      user.score = req.body.score;
      await user.save();
    }
    res.json({ message: 'Score updated' });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

app.get('/api/leaderboard', async (req, res) => {
  const topUsers = await User.find().sort({ score: -1 }).limit(10);
  res.json(topUsers);
});

app.listen(4000, () => console.log('Server running on port 4000'));


app.post('/api/admin', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'password1') {
    const token = jwt.sign({ admin: true }, process.env.JWT_SECRET);
    return res.json({ token });
  }
  res.status(401).json({ error: 'Unauthorized' });
});
